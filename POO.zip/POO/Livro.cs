﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO
{
    internal class Livro
    {
        //Atributos
        public string titulo;
        public string autor;
        public int paginas;
    }
}

