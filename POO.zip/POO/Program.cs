﻿// Listas
//string[] nomes = new string[5];
//Generico
//versoes antigas do C#
//List<string> listaDeNomes2 = new List<string>();

////jeito novo de escrever
//List<string> listaDeNomes = new();

//listaDeNomes.Add("Marco");
//listaDeNomes.Add("Fulano");
//listaDeNomes.Add("Sicrano");
//listaDeNomes.Add("Beltrano");

//foreach (var item in listaDeNomes)
//{
//        Console.WriteLine(item);
//}

//listaDeNomes.Remove("Sicrano")

//POO - Programacao Orientada a Objetos
// Inicio em programacao estruturada 
// POO tem como objetivo aproximar a programacao do mundo real
// Separr nossos sistemas em partes menores

//Divido em classes e objetos

// Classe - definicao: item da vida real representado em codigo
// Toda classe tem atributos (caracteristicas) e metodos (acoes)

//Objeto - Instancia de uma classe
using POO;

//Carro carro1 = new Carro();
//carro1.modelo = "HB20";
//carro1.marca = "Hyundai";
//carro1.anoFabricacao = 2024;

//carro1.Andar();
//carro1.Parar();

//Carro carro2 = new Carro();
//carro2.modelo = "Fusca";
//carro2.marca = "VW";
//carro2.anoFabricacao = 1969;

//carro2.Andar();
//carro2.Parar();

//Carro carro3 = new Carro();

//carro3.modelo = "Silver Shadow";
//carro3.marca = "Rolls Royce";
//carro3.anoFabricacao = 2023;

//carro3.Andar();
//carro3.Parar();

//List<Carro> carros = new List<Carro>();
//carros.Add(carro1);
//carros.Add(carro2);
//carros.Add(carro3);

//*** Criando Objetos e Classes (25/03)
using POO;

Livro livro1 = new Livro();
livro1.titulo = "As trancas do rei careca";
livro1.paginas = 242;
livro1.autor = "Joao Traumatizado";